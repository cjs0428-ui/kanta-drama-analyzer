메리츠 간편보험 2030 시바견 릴스 - '검진 소견' 버전 v6 소스

01_final        최종 영상 (1080x1920, 30fps, 33.1초)
02_source_video 수정 기준 원본 (v3 최종 33초: 잡음 제거·공백 단축 반영본)
03_scripts      편집 스크립트
  - procA2.py   프레임 단위 편집 전체(오프닝 문구 교체, 검색 화면 교체, 오해 카드·상자 문구 교체, 자막 교체)
  - ui.py/ui.cjs        검색 화면 단계별(S0~S5) 렌더링
  - cap.html/cap.cjs    오프닝 강조 문구(나눔명조 800, 불꽃 그라데이션)
  - sub*.html/sub*.cjs  하단 자막(Noto Sans KR 700, 검은 상자·노란 강조)
  - txt.html/txt.cjs    오해 카드·'소견이 있어도' 상자 문구
04_overlays     렌더링된 문구·화면 PNG(투명 배경, 1080x1920 기준 위치)
05_audio
  - mix_final.wav       최종 믹스
  - narration/          새 내레이션 4문장 (L0_3=1문장, R1_3=2문장, R2_3=3문장, L4s_2=4문장 / *f.wav = 속도 보정본)
  - stems/              원본에서 분리한 배경음(instrumental)·목소리(vocals)
  - voice_refs/         목소리 생성 레퍼런스 (rC·rD 사용 권장. srefA·srefB는 원래 1·2문장이 들어 있어 따라 읽는 문제가 있었음)
06_plan         기획안(PPT/PDF) + 컷별 스크린샷

폰트: Noto Sans KR, Nanum Myeongjo(@fontsource), Pretendard(npm) - 스크립트 실행 시 npm으로 설치
생성 모델: 목소리 Higgsfield Seed Audio 1.0 (레퍼런스 클론), 음원 분리 UVR-MDX-NET-Voc_FT
